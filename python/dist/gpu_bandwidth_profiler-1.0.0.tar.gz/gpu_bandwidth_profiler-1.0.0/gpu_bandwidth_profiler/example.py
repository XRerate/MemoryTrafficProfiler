#!/usr/bin/env python3
"""
Example usage of the GPU Bandwidth Profiler Python client.

This script connects to a GPU Bandwidth Profiler server running on an Android device
and demonstrates how to control profiling and retrieve data.
"""

import sys
import time
from gpu_bandwidth_profiler import GPUBandwidthClient, BandwidthData


def main():
    """Example usage of the client."""
    # Get server address from command line or use default
    # Usage: python example.py [host] [port]
    host = sys.argv[1] if len(sys.argv) > 1 else "localhost"
    port = int(sys.argv[2]) if len(sys.argv) > 2 else 8888
    
    print("=" * 60)
    print("GPU Bandwidth Profiler - Python Client Example")
    print("=" * 60)
    print(f"Connecting to server at {host}:{port}...")
    print()
    
    # Use context manager for automatic connection handling
    with GPUBandwidthClient(host, port) as client:
        # Check connection
        if not client.ping():
            print("ERROR: Server is not responding")
            print("Make sure:")
            print("  1. Server is running on the device")
            print("  2. Port forwarding is set up: adb forward tcp:8888 tcp:8888")
            print("  3. Firewall allows connections on port", port)
            return 1
        
        print("✓ Connected successfully!")
        print()
        
        # Get status
        print("=== Server Status ===")
        status = client.get_status()
        print(f"Backend: {status.get('backend', 'Unknown')}")
        print(f"Profiling: {status.get('profiling', 'Unknown')}")
        print()
        
        # Example 1: Basic profiling
        print("=== Example 1: Basic Profiling ===")
        print("Starting profiling with 200ms interval...")
        if not client.start(200):
            print("ERROR: Failed to start profiling")
            return 1
        
        print("Profiling for 3 seconds...")
        time.sleep(3)
        
        print("Stopping profiling...")
        client.stop()
        print()
        
        # Example 2: Get sample data
        print("=== Example 2: Sample Data ===")
        data = client.get_data()
        if data:
            print(f"Retrieved {len(data)} samples")
            print("First 5 samples:")
            for i, sample in enumerate(data[:5]):
                print(f"  Sample {i}: "
                      f"Read={sample.read_bandwidth_mbps:.4f} MB/s, "
                      f"Write={sample.write_bandwidth_mbps:.4f} MB/s, "
                      f"Total={sample.total_bandwidth_mbps:.4f} MB/s")
        else:
            print("No data available.")
        print()
        
        # Example 3: Continuous monitoring
        print("=== Example 3: Continuous Monitoring ===")
        client.clear_buffer()
        print("Starting profiling with 100ms interval for 5 seconds...")
        if not client.start(100):
            print("ERROR: Failed to start profiling")
            return 1
        
        # Monitor for 5 seconds
        for i in range(5):
            time.sleep(1)
            data = client.get_data()
            if data:
                latest = data[-1]
                print(f"  [{i+1}s] Samples: {len(data)}, "
                      f"Current: {latest.total_bandwidth_mbps:.2f} MB/s")
        
        client.stop()
        
        # Final data summary
        final_data = client.get_data()
        print()
        print("=== Final Summary ===")
        print(f"Total Samples: {len(final_data)}")
        if final_data:
            first_ts = final_data[0].timestamp_ns
            last_ts = final_data[-1].timestamp_ns
            duration = (last_ts - first_ts) / 1e9
            print(f"Duration: {duration:.2f} seconds")
    
    print()
    print("Example completed successfully!")
    return 0


if __name__ == "__main__":
    exit(main())

