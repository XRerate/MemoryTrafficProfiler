#!/usr/bin/env python3
"""
Real-time GPU bandwidth monitoring script.
"""

import sys
import time
from gpu_bandwidth_profiler import GPUBandwidthClient


def main():
    host = sys.argv[1] if len(sys.argv) > 1 else "localhost"
    port = int(sys.argv[2]) if len(sys.argv) > 2 else 8888
    
    print(f"GPU Bandwidth Monitor - Connecting to {host}:{port}")
    print("=" * 70)
    
    with GPUBandwidthClient(host, port) as client:
        if not client.ping():
            print("ERROR: Cannot connect to server!")
            return 1
        
        # Get initial status
        status = client.get_status()
        backend = status.get('backend', 'Unknown')
        is_profiling = status.get('profiling', 'false') == 'true'
        
        print(f"Backend: {backend}")
        print(f"Profiling: {'Active' if is_profiling else 'Inactive'}")
        print()
        
        if not is_profiling:
            print("⚠️  Profiling is not active. Starting profiling...")
            # Clear buffer to start fresh
            client.clear_buffer()
            print("✓ Buffer cleared")
            if not client.start(100):  # 100ms interval
                print("ERROR: Failed to start profiling!")
                print("Note: This may be because no GPU backend is available.")
                return 1
            print("✓ Profiling started with 100ms interval")
            time.sleep(1)  # Wait a moment for data to accumulate
        else:
            # Profiling is already active, but clear buffer for fresh monitoring
            print("ℹ️  Profiling is already active. Clearing buffer for fresh monitoring...")
            client.clear_buffer()
            print("✓ Buffer cleared")
        
        print("\n" + "=" * 70)
        print("Real-time Bandwidth Monitoring (Press Ctrl+C to stop)")
        print("=" * 70)
        print(f"{'Time':<12} {'Samples':<10} {'Read MB/s':<12} {'Write MB/s':<12} "
              f"{'Total MB/s':<12} {'Peak R/W/T':<12}")
        print("-" * 70)
        
        try:
            while True:
                try:
                    data = client.get_data()
                    current_time = time.strftime('%H:%M:%S')
                    
                    if data:
                        latest = data[-1]
                        peak_read = max(s.read_bandwidth_mbps for s in data)
                        peak_write = max(s.write_bandwidth_mbps for s in data)
                        peak_total = max(s.total_bandwidth_mbps for s in data)
                        peak_str = f"{peak_read:.0f}/{peak_write:.0f}/{peak_total:.0f}"
                        print(f"{current_time:<12} {len(data):<10} "
                              f"{latest.read_bandwidth_mbps:<12.2f} "
                              f"{latest.write_bandwidth_mbps:<12.2f} "
                              f"{latest.total_bandwidth_mbps:<12.2f} "
                              f"{peak_str:<12}")
                    else:
                        print(f"{current_time:<12} {'Waiting...':<10} "
                              f"{'N/A':<12} {'N/A':<12} {'N/A':<12} {'N/A':<12}")
                except RuntimeError as e:
                    print(f"\n⚠️  Error getting data: {e}")
                    print("Attempting to reconnect...")
                    try:
                        client.disconnect()
                        client.connect()
                        if not client.ping():
                            print("ERROR: Cannot reconnect to server")
                            break
                        print("✓ Reconnected successfully")
                    except Exception as reconnect_error:
                        print(f"ERROR: Failed to reconnect: {reconnect_error}")
                        break
                
                time.sleep(2)  # Update every 2 seconds
                
        except KeyboardInterrupt:
            print("\n\nStopping monitoring...")
            client.stop()
            
            # Show final summary
            print("\n" + "=" * 70)
            print("Final Summary")
            print("=" * 70)
            final_data = client.get_data()
            if final_data:
                first_ts = final_data[0].timestamp_ns
                last_ts = final_data[-1].timestamp_ns
                duration = (last_ts - first_ts) / 1e9
                print(f"Total Samples:    {len(final_data)}")
                print(f"Duration:        {duration:.2f} seconds")
                if final_data:
                    latest = final_data[-1]
                    peak_read = max(s.read_bandwidth_mbps for s in final_data)
                    peak_write = max(s.write_bandwidth_mbps for s in final_data)
                    peak_total = max(s.total_bandwidth_mbps for s in final_data)
                    print(f"\nLatest Values (current):")
                    print(f"  Read:          {latest.read_bandwidth_mbps:.2f} MB/s")
                    print(f"  Write:         {latest.write_bandwidth_mbps:.2f} MB/s")
                    print(f"  Total:         {latest.total_bandwidth_mbps:.2f} MB/s")
                    print(f"\nPeak Values (maximum):")
                    print(f"  Read:          {peak_read:.2f} MB/s")
                    print(f"  Write:         {peak_write:.2f} MB/s")
                    print(f"  Total:         {peak_total:.2f} MB/s")
            else:
                print("No data collected.")
            print("=" * 70)
    
    return 0


if __name__ == "__main__":
    exit(main())

