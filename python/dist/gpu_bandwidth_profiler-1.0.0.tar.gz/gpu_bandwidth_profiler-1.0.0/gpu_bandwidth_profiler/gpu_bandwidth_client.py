"""
Python client for GPU Bandwidth Profiler server.

This client connects to a GPU Bandwidth Profiler server running on an Android device
and provides a Python interface to control profiling and retrieve data.
"""

import socket
import json
import time
from typing import Optional, List, Dict, Tuple
from dataclasses import dataclass


@dataclass
class BandwidthData:
    """Bandwidth data sample."""
    read_bandwidth_mbps: float
    write_bandwidth_mbps: float
    total_bandwidth_mbps: float
    timestamp_ns: int


@dataclass
class BandwidthStatistics:
    """Bandwidth statistics for a time period."""
    sample_count: int
    read_avg_mbps: float
    read_max_mbps: float
    read_median_mbps: float
    write_avg_mbps: float
    write_max_mbps: float
    write_median_mbps: float
    total_avg_mbps: float
    total_max_mbps: float
    total_median_mbps: float
    start_timestamp_ns: int
    end_timestamp_ns: int
    duration_sec: float


class GPUBandwidthClient:
    """Client for GPU Bandwidth Profiler server."""
    
    def __init__(self, host: str = "localhost", port: int = 8888, timeout: float = 5.0):
        """
        Initialize the client.
        
        Args:
            host: Server hostname or IP address
            port: Server port number
            timeout: Socket timeout in seconds
        """
        self.host = host
        self.port = port
        self.timeout = timeout
        self.sock: Optional[socket.socket] = None
    
    def connect(self) -> bool:
        """Connect to the server."""
        try:
            self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.sock.settimeout(self.timeout)
            self.sock.connect((self.host, self.port))
            return True
        except Exception as e:
            print(f"Failed to connect to {self.host}:{self.port}: {e}")
            return False
    
    def disconnect(self):
        """Disconnect from the server."""
        if self.sock:
            self.sock.close()
            self.sock = None
    
    def _send_command(self, command: str) -> str:
        """Send a command to the server and return the response."""
        # Reconnect if needed
        if not self.sock:
            if not self.connect():
                raise RuntimeError("Not connected to server and failed to reconnect.")
        
        max_retries = 2
        for attempt in range(max_retries):
            try:
                # Send command
                self.sock.sendall((command + "\n").encode())
                
                # Read response - may need multiple recv calls for complete response
                response = ""
                self.sock.settimeout(5.0)  # Set timeout for reading
                
                while True:
                    try:
                        chunk = self.sock.recv(4096).decode()
                        if not chunk:
                            # Connection closed by server - this is normal after response
                            break
                        response += chunk
                        # Check if we have a complete response (ends with newline)
                        if response.endswith("\n"):
                            break
                        # For single-line responses, we're done after first newline
                        if "\n" in response and not command.startswith("GET_DATA"):
                            break
                    except socket.timeout:
                        if response:
                            break  # We have some response, return it
                        raise RuntimeError("Timeout waiting for server response")
                
                if not response:
                    # Empty response - connection might be closed
                    if attempt < max_retries - 1:
                        # Try to reconnect and retry
                        self.disconnect()
                        if not self.connect():
                            raise RuntimeError("Server closed connection and failed to reconnect")
                        continue
                    raise RuntimeError("Empty response from server")
                
                return response.strip()
            except (socket.error, ConnectionError, BrokenPipeError) as e:
                # Connection error - try to reconnect
                if attempt < max_retries - 1:
                    try:
                        self.disconnect()
                        if not self.connect():
                            raise RuntimeError(f"Connection lost and failed to reconnect: {e}")
                        continue  # Retry the command
                    except Exception:
                        pass
                raise RuntimeError(f"Connection lost: {e}. Please reconnect.")
            except Exception as e:
                raise RuntimeError(f"Failed to communicate with server: {e}")
        
        raise RuntimeError("Failed to send command after retries")
    
    def ping(self) -> bool:
        """Check if server is responsive."""
        try:
            response = self._send_command("PING")
            return response.startswith("OK PONG")
        except:
            return False
    
    def get_status(self) -> Dict[str, str]:
        """Get server status."""
        response = self._send_command("GET_STATUS")
        if not response.startswith("OK STATUS"):
            raise RuntimeError(f"Unexpected response: {response}")
        
        # Parse response: "OK STATUS profiling=true backend=Mali"
        parts = response.split(" ", 2)
        if len(parts) < 3:
            raise RuntimeError(f"Invalid status response: {response}")
        
        status_str = parts[2]
        status = {}
        for item in status_str.split():
            if "=" in item:
                key, value = item.split("=", 1)
                status[key] = value
        
        return status
    
    def start(self, sampling_interval_ms: int = 100) -> bool:
        """
        Start bandwidth profiling.
        
        Args:
            sampling_interval_ms: Sampling interval in milliseconds
            
        Returns:
            True if successful, False otherwise
        """
        response = self._send_command(f"START {sampling_interval_ms}")
        return response.startswith("OK")
    
    def stop(self) -> bool:
        """Stop bandwidth profiling."""
        response = self._send_command("STOP")
        return response.startswith("OK")
    
    def clear_buffer(self) -> bool:
        """Clear the accumulator buffer."""
        response = self._send_command("CLEAR")
        return response.startswith("OK")
    
    def get_data(self) -> List[BandwidthData]:
        """Get accumulated bandwidth data."""
        if not self.sock:
            if not self.connect():
                raise RuntimeError("Not connected to server and failed to reconnect.")
        
        try:
            # Send command
            self.sock.sendall(b"GET_DATA\n")
            
            # Read complete response (may need multiple recv calls)
            buffer = ""
            while True:
                chunk = self.sock.recv(4096).decode()
                if not chunk:
                    break
                buffer += chunk
                # Check if we have complete response (ends with END\n)
                if buffer.endswith("END\n") or buffer.endswith("END\r\n"):
                    break
            
            if not buffer.startswith("OK DATA"):
                raise RuntimeError(f"Unexpected response: {buffer[:100]}")
            
            # Parse data
            data_list = []
            for line in buffer.split("\n"):
                line = line.strip()
                if line.startswith("SAMPLE"):
                    parts = line.split()
                    if len(parts) >= 6:
                        try:
                            data_list.append(BandwidthData(
                                read_bandwidth_mbps=float(parts[2]),
                                write_bandwidth_mbps=float(parts[3]),
                                total_bandwidth_mbps=float(parts[4]),
                                timestamp_ns=int(parts[5])
                            ))
                        except (ValueError, IndexError):
                            continue
                elif line == "END":
                    break
            
            return data_list
        except socket.error as e:
            # Connection error - try to reconnect
            self.disconnect()
            raise RuntimeError(f"Connection lost: {e}. Please reconnect.")
        except Exception as e:
            raise RuntimeError(f"Failed to get data from server: {e}")
    
    def get_statistics(self, stat_start: int, stat_end: int) -> BandwidthStatistics:
        """
        Get bandwidth statistics for a specified time period.
        
        Args:
            stat_start: Start timestamp in nanoseconds (inclusive)
            stat_end: End timestamp in nanoseconds (inclusive)
            
        Returns:
            BandwidthStatistics object with average, maximum, and median values
            
        Raises:
            ValueError: If stat_start >= stat_end or no samples in range
        """
        if stat_start >= stat_end:
            raise ValueError("stat_start must be less than stat_end")
        
        # Get all data
        all_data = self.get_data()
        
        # Filter samples within the time range
        filtered_data = [
            sample for sample in all_data
            if stat_start <= sample.timestamp_ns <= stat_end
        ]
        
        if not filtered_data:
            raise ValueError(f"No samples found in time range [{stat_start}, {stat_end}]")
        
        # Calculate statistics
        read_values = [s.read_bandwidth_mbps for s in filtered_data]
        write_values = [s.write_bandwidth_mbps for s in filtered_data]
        total_values = [s.total_bandwidth_mbps for s in filtered_data]
        
        # Sort for median calculation
        read_sorted = sorted(read_values)
        write_sorted = sorted(write_values)
        total_sorted = sorted(total_values)
        
        n = len(filtered_data)
        median_idx = n // 2
        
        def calculate_median(sorted_list):
            if n % 2 == 0:
                return (sorted_list[median_idx - 1] + sorted_list[median_idx]) / 2.0
            else:
                return sorted_list[median_idx]
        
        return BandwidthStatistics(
            sample_count=n,
            read_avg_mbps=sum(read_values) / n,
            read_max_mbps=max(read_values),
            read_median_mbps=calculate_median(read_sorted),
            write_avg_mbps=sum(write_values) / n,
            write_max_mbps=max(write_values),
            write_median_mbps=calculate_median(write_sorted),
            total_avg_mbps=sum(total_values) / n,
            total_max_mbps=max(total_values),
            total_median_mbps=calculate_median(total_sorted),
            start_timestamp_ns=stat_start,
            end_timestamp_ns=stat_end,
            duration_sec=(stat_end - stat_start) / 1e9
        )
    
    def __enter__(self):
        """Context manager entry."""
        self.connect()
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        self.disconnect()


def main():
    """Example usage of the client."""
    import sys
    
    # Get server address from command line or use default
    host = sys.argv[1] if len(sys.argv) > 1 else "localhost"
    port = int(sys.argv[2]) if len(sys.argv) > 2 else 8888
    
    print(f"Connecting to GPU Bandwidth Server at {host}:{port}...")
    
    with GPUBandwidthClient(host, port) as client:
        # Check connection
        if not client.ping():
            print("ERROR: Server is not responding")
            return 1
        
        print("Connected successfully!")
        
        # Get status
        status = client.get_status()
        print(f"Backend: {status.get('backend', 'Unknown')}")
        print(f"Profiling: {status.get('profiling', 'Unknown')}")
        print()
        
        # Start profiling
        print("Starting profiling with 200ms interval...")
        if not client.start(200):
            print("ERROR: Failed to start profiling")
            return 1
        
        # Wait for some data
        print("Profiling for 3 seconds...")
        time.sleep(3)
        
        # Stop profiling
        print("Stopping profiling...")
        client.stop()
        
        # Get sample data
        data = client.get_data()
        if data:
            print(f"\nRetrieved {len(data)} samples")
            print("First 5 samples:")
            for i, sample in enumerate(data[:5]):
                print(f"  Sample {i}: Read={sample.read_bandwidth_mbps:.4f} MB/s, "
                      f"Write={sample.write_bandwidth_mbps:.4f} MB/s, "
                      f"Total={sample.total_bandwidth_mbps:.4f} MB/s")
    
    print("\nDone!")
    return 0


if __name__ == "__main__":
    exit(main())

