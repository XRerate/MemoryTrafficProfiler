#!/usr/bin/env python3
"""
Simple script to view GPU bandwidth profiling results from the server.
"""

import sys
import time
from gpu_bandwidth_profiler import GPUBandwidthClient, BandwidthData


def print_summary(data: list):
    """Print bandwidth data summary."""
    if not data:
        print("\n" + "=" * 60)
        print("No data collected yet.")
        print("=" * 60)
        return
    
    print("\n" + "=" * 60)
    print("GPU Bandwidth Data Summary")
    print("=" * 60)
    print(f"Sample Count:     {len(data)}")
    
    first_ts = data[0].timestamp_ns
    last_ts = data[-1].timestamp_ns
    duration = (last_ts - first_ts) / 1e9
    print(f"Duration:         {duration:.2f} seconds")
    if duration > 0:
        print(f"Sampling Rate:    {len(data) / duration:.1f} samples/sec")
    print("=" * 60)


def print_samples(data: list, max_samples: int = 10):
    """Print bandwidth data samples."""
    if not data:
        print("No samples available.")
        return
    
    print(f"\nShowing {min(len(data), max_samples)} of {len(data)} samples:")
    print("-" * 80)
    print(f"{'#':<4} {'Read (MB/s)':<15} {'Write (MB/s)':<15} {'Total (MB/s)':<15} {'Timestamp':<20}")
    print("-" * 80)
    
    for i, sample in enumerate(data[:max_samples]):
        timestamp_sec = sample.timestamp_ns / 1e9
        print(f"{i+1:<4} {sample.read_bandwidth_mbps:<15.4f} "
              f"{sample.write_bandwidth_mbps:<15.4f} "
              f"{sample.total_bandwidth_mbps:<15.4f} "
              f"{timestamp_sec:<20.6f}")


def main():
    host = sys.argv[1] if len(sys.argv) > 1 else "localhost"
    port = int(sys.argv[2]) if len(sys.argv) > 2 else 8888
    
    print(f"Connecting to server at {host}:{port}...")
    
    with GPUBandwidthClient(host, port) as client:
        # Check connection
        if not client.ping():
            print("ERROR: Cannot connect to server!")
            return 1
        
        print("Connected successfully!\n")
        
        # Get status
        status = client.get_status()
        print(f"Server Status:")
        print(f"  Backend:  {status.get('backend', 'Unknown')}")
        print(f"  Profiling: {status.get('profiling', 'Unknown')}")
        
        # Get sample data
        print("\nFetching sample data...")
        data = client.get_data()
        print_summary(data)
        print_samples(data, max_samples=20)
        
        # If profiling is active, show real-time updates
        if status.get('profiling') == 'true':
            print("\n" + "=" * 60)
            print("Profiling is active. Showing real-time updates (Ctrl+C to stop):")
            print("=" * 60)
            try:
                while True:
                    time.sleep(2)
                    current_data = client.get_data()
                    if current_data:
                        latest = current_data[-1]
                        print(f"\r[{time.strftime('%H:%M:%S')}] "
                              f"Samples: {len(current_data):4d} | "
                              f"Current: {latest.total_bandwidth_mbps:8.2f} MB/s",
                              end='', flush=True)
            except KeyboardInterrupt:
                print("\n\nStopped monitoring.")
        
    return 0


if __name__ == "__main__":
    exit(main())

