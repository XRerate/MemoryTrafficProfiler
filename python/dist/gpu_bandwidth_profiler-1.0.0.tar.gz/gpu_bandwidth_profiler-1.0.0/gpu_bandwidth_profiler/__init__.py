"""
GPU Bandwidth Profiler - Python Client Package

A Python client library for controlling the GPU Bandwidth Profiler server
running on Android devices.
"""

from .gpu_bandwidth_client import (
    GPUBandwidthClient,
    BandwidthData,
    BandwidthStatistics,
)

__version__ = "1.0.0"
__all__ = [
    "GPUBandwidthClient",
    "BandwidthData",
    "BandwidthStatistics",
]

