# GPU Bandwidth Profiler - Python Client

Python client library for controlling the GPU Bandwidth Profiler server running on Android devices.

## Overview

This client-server architecture allows you to:
- Run the GPU Bandwidth Profiler server on an Android device
- Control profiling and retrieve data from a Python client on your host machine
- Monitor GPU bandwidth remotely over a network connection

## Architecture

```
┌─────────────────┐         TCP/IP         ┌──────────────────┐
│  Python Client  │ ◄──────────────────► │  Server (Android) │
│   (Host PC)     │    Port 8888 (default) │   (Device)        │
└─────────────────┘                        └──────────────────┘
```

## Setup

### 1. Build and Deploy Server to Android Device

```bash
# Build server for Android (Mali backend)
bazel build --config=android_mali //src/server:gpu_bandwidth_server

# Deploy to device
adb push bazel-bin/src/server/gpu_bandwidth_server /data/local/tmp/
adb shell chmod +x /data/local/tmp/gpu_bandwidth_server
```

### 2. Start Server on Device

```bash
# Start server on device (default port 8888)
adb shell /data/local/tmp/gpu_bandwidth_server

# Or specify a custom port
adb shell /data/local/tmp/gpu_bandwidth_server 9999
```

### 3. Forward Port (if connecting from host)

```bash
# Forward device port to host
adb forward tcp:8888 tcp:8888
```

### 4. Use Python Client

```python
from gpu_bandwidth_client import GPUBandwidthClient

# Connect to server
client = GPUBandwidthClient(host="localhost", port=8888)
client.connect()

# Start profiling
client.start(sampling_interval_ms=200)

# ... do some work ...

# Stop profiling
client.stop()

# Get sample data
data = client.get_data()
print(f"Collected {len(data)} samples")

client.disconnect()
```

## Protocol

The server uses a simple text-based protocol over TCP:

### Commands

- `START <interval_ms>` - Start profiling with specified interval
- `STOP` - Stop profiling
- `GET_DATA` - Get accumulated bandwidth data
- `GET_STATUS` - Get server status
- `CLEAR` - Clear accumulator buffer
- `PING` - Check if server is responsive

### Responses

- `OK <data>` - Success response with data
- `ERROR <message>` - Error response

## Example Usage

See `example.py` for a complete example.

## API Reference

### GPUBandwidthClient

#### Methods

- `connect()` - Connect to the server
- `disconnect()` - Disconnect from the server
- `ping()` - Check if server is responsive
- `get_status()` - Get server status (backend name, profiling state)
- `start(sampling_interval_ms=100)` - Start bandwidth profiling
- `stop()` - Stop bandwidth profiling
- `clear_buffer()` - Clear the accumulator buffer
- `get_data()` - Get accumulated bandwidth data as list of BandwidthData

### Data Structures

#### BandwidthData
- `read_bandwidth_mbps: float`
- `write_bandwidth_mbps: float`
- `total_bandwidth_mbps: float`
- `timestamp_ns: int`


