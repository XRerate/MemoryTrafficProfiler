"""Setup script for GPU Bandwidth Profiler Python client."""

from setuptools import setup, find_packages
from pathlib import Path

# Read the README file
readme_file = Path(__file__).parent / "README.md"
long_description = readme_file.read_text() if readme_file.exists() else ""

setup(
    name="gpu-bandwidth-profiler",
    version="1.0.0",
    description="Python client for GPU Bandwidth Profiler server",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="GPU Bandwidth Profiler Contributors",
    url="https://github.com/yourusername/GPUBandwidthProfiler",
    packages=find_packages(),
    python_requires=">=3.7",
    install_requires=[],
    extras_require={
        "dev": [
            "pytest>=6.0",
            "pytest-cov>=2.0",
            "black>=21.0",
            "mypy>=0.900",
        ],
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: System :: Hardware",
    ],
    entry_points={
        "console_scripts": [
            "gpu-bandwidth-monitor=gpu_bandwidth_profiler.monitor:main",
            "gpu-bandwidth-view=gpu_bandwidth_profiler.view_results:main",
        ],
    },
)

